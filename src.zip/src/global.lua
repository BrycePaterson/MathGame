--List of global variables that exist
	--gv.hit
	--gv.range
	--gv.permission (1 for yes, 0 for no)
	--gv.height
	--gv.width

g = {}

return g