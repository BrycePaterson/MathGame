--List of global variables that exist
	--gv.hit
	--gv.range
	--gv.permission (1 for yes, 0 for no)
	--gv.height
	--gv.width
	--gv.section -- 0 for addition; 1 for subtraction, 2 for Multiplication, 3 for Division
	--gv.progress
	--gv.gold --holds how much money the user has
	--gv.owned holds a record of which skins the user has bought
	--gv.currentskin
	--gv.skinlist
	--gv.equip holds the skin number for gv.skinlist that the user has currently selected
	--gv.levelPlayed is the level the user is currently playing
g = {}

return g